<?php
$name = $_POST['name'];
echo "<p>"."Encantado de conocerte, $name"."</p>";
echo "<a href=\"../index.html\">HOME</a>";