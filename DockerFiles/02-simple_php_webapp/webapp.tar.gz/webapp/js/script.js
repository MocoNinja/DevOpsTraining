window.addEventListener("load", function() {
    console.log("Iniciada la aplicación a " + new Date());
});